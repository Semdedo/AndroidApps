package com.gfiamoncini.calculadora;

import androidx.appcompat.app.AppCompatActivity;

//Imports das bibliotecas necessarias
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private float resultado;
    private double primeiroElemento = 0;
    private int segundoElementoIndex = 0;
    private boolean operador = false;
    private  char operadorAtual;

    //Variaveis para botao
    private Button btn0;
    private Button btn1;
    private Button btn2;
    private Button btn3;
    private Button btn4;
    private Button btn5;
    private Button btn6;
    private Button btn7;
    private Button btn8;
    private Button btn9;
    private Button btnPonto;

    //Variaveis  para os operadores
    private Button btnDiv;
    private Button btnSub;
    private Button btnMul;
    private Button btnSom;
    private Button btnIgual;

    //TextLabel e limpar
    private TextView txt;
    private Button btnLimpar;
    private Button btnClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Definido ids para os botões conforme ID do layout
        btn0 = findViewById(R.id.btn0);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);
        btnPonto = findViewById(R.id.btnPonto);
        btnLimpar = findViewById(R.id.btnLimpar);
        btnClear = findViewById(R.id.btnClear);

        //Operadores
        btnIgual = findViewById(R.id.btnIgual);
        btnSom = findViewById(R.id.btnSom);
        btnSub = findViewById(R.id.btnSub);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);

        //Label de Resultado
        txt = findViewById(R.id.txt);

        //Metodos Click para mostrar os botões precionados
        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_0","=============== botao 0");
                //txt.setText("0"); // realizado texte  para ver se estava funcionando, usando append para replicar a informacao no texview e nao sobescrever
                txt.append("0");
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_1","=============== botao 1");
                txt.append("1");

            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_2","=============== botao 2");
                //txt.setText("2");
                txt.append("2");
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_3","=============== botao 3");
                //txt.setText("3");
                txt.append("3");
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_4","=============== botao 4");
                //txt.setText("4");
                txt.append("4");
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_5","=============== botao 5");
                //txt.setText("5");
                txt.append("5");
            }
        });

        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("botao_6","=============== botao 6");
                //txt.setText("6");
                txt.append("6");
            }
        });

        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_7", "=============== botao 7");
                //txt.setText("7");
                txt.append("7");
            }
        });

        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_8","=============== botao 8");
                //txt.setText("8");
                txt.append("8");
            }
        });

        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_9","=============== botao 9");
                //txt.setText("9");
                txt.append("9");
            }
        });

        btnPonto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_Ponto", "========== botao ponto");
                txt.append(".");
            }
        });

        // Operadores
        btnSom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_soma","============= botao soma");
                String screenContent = txt.getText().toString();
                segundoElementoIndex = screenContent.length()+1;
                primeiroElemento = Double.parseDouble(screenContent);
                txt.append("+");
                operador=true;
                operadorAtual = '+';
            }
        });

        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_subracao","========== botao subtracao");
                String screenContent = txt.getText().toString();
                segundoElementoIndex = screenContent.length()+1;
                primeiroElemento = Double.parseDouble(screenContent);
                txt.append("-");
                operador=true;
                operadorAtual = '-';
            }
        });

        btnMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_multiplicacao","=========== botao multiplicacao");
                String screenContent = txt.getText().toString();
                segundoElementoIndex = screenContent.length()+1;
                primeiroElemento = Double.parseDouble(screenContent);
                txt.append("x");
                operador=true;
                operadorAtual = 'x';
            }
        });

        btnDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_divisao","================ botao divisao");
                String screenContent = txt.getText().toString();
                segundoElementoIndex = screenContent.length()+1;
                primeiroElemento = Double.parseDouble(screenContent);
                txt.append("/");
                operador=true;
                operadorAtual = '/';
            }
        });

        //Limpar tela e texlabel
        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_limpar","================ botao_limpar");

                //implementacao para limpar sempre o ultimo valor informado, caso teha apenas um elemento limpa a o textview caso tenha mais que 1 limpa o ultimo informado.
                String displayedElements = txt.getText().toString();
                int length = displayedElements.length();
                if(length > 0 ){
                    displayedElements = displayedElements.substring(0,length-1);
                    txt.setText(displayedElements);
                }
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt.setText("");
            }
        });

        btnIgual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("botao_igual", "=========== botao igual");

                //Verifica o status do operador se for verdadeiro entra no IF
                if(operador){
                    //Verifica qual operador foi carregado ao pressionar um dos botoes
                    if(operadorAtual=='+')
                    {
                        String screenContent = txt.getText().toString();
                        String segundovalorString = screenContent.substring(segundoElementoIndex, screenContent.length());
                        double segundovalor = Double.parseDouble(segundovalorString);
                        segundovalor+=primeiroElemento;
                       txt.setText(String.valueOf(segundovalor));
                    }
                    else if(operadorAtual=='-')
                    {
                        String screenContent = txt.getText().toString();
                        String segundovalorString = screenContent.substring(segundoElementoIndex, screenContent.length());
                        double segundovalor = Double.parseDouble(segundovalorString);
                        primeiroElemento -= segundovalor;
                        txt.setText(String.valueOf(primeiroElemento));
                    }
                    else if(operadorAtual=='x')
                    {
                        String screenContent = txt.getText().toString();
                        String segundovalorString = screenContent.substring(segundoElementoIndex, screenContent.length());
                        double segundovalor = Double.parseDouble(segundovalorString);
                        segundovalor *= primeiroElemento;
                        txt.setText(String.valueOf(segundovalor));
                    }
                    else if(operadorAtual=='/')
                    {
                        String screenContent = txt.getText().toString();
                        String segundovalorString = screenContent.substring(segundoElementoIndex, screenContent.length());
                        double segundovalor = Double.parseDouble(segundovalorString);
                        primeiroElemento /= segundovalor;
                        //segundovalor /= primeiroElemento; // Se colocar o segundo elemento mostra o resto da divisao.
                        txt.setText(String.valueOf(primeiroElemento));
                    }
                }
                //txt.setText("teste de impressao");
            }
        });
    }
}
